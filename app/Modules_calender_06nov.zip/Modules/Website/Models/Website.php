<?php

namespace App\Modules\Website\Models;

use Illuminate\Database\Eloquent\Model;

class Website extends Model {

    //

}
