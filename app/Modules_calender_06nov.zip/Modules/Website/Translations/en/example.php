<?php 

return [
    'welcome' => 'Welcome, this is Website module.'
];
