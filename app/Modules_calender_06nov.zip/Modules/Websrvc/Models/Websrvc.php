<?php

	namespace App\Modules\Websrvc\Models;

	use Illuminate\Database\Eloquent\Model;
	use DB;
	class Websrvc extends Model {

	public function AreaList()
	{
		
        $arealistSql = DB::table('tbl_lr_governorate_area')
      				->where('admin_status',1)
      				->get(['lr_governorate_area_id','lr_governorate_area_name']);
      				
      	$arealist = [];
      	foreach ($arealistSql as $value) 
      	{
      		$lr_governorate_area_id = $value->lr_governorate_area_id;
      		$lr_governorate_area_name = $value->lr_governorate_area_name;
      		$arealist[] = [
      					"area_id" => $lr_governorate_area_id,
      					"area_name" => $lr_governorate_area_name
      					];
      	}

      return ([
		      	"status" => 200,
		      	"msg" => 'Successfully Retrieve Information.',
		      	"arealist" => $arealist     
		      ]);

	}// end of AreaList function

	public function RegisterUser($request) // start of RegisterUser function
	{
		$first_name = $request->first_name; 
		$last_name = $request->last_name; 
        $password = $request->password; 
        $email = $request->email; 
        $gender = $request->gender; 
        $dob = $request->dob; 
		$area_id = $request->area_id; 
		$userid = uniqid();
		$lng_type = $request->lng_type;
		$curDate = new \DateTime();
		
		$email_exist = isemail_exist('tbl_app_user','app_user_email',$email); 
		if($email_exist > 0){
			return ([
			'status' =>'401',
			'msg' => 'E-mail already registered'
			]);
		}
		else
		{
		if($first_name!='' && $last_name!='' && $password!='' && $email!='' && $gender!='' && $dob!='' && $area_id!='')
		{
		$sql=DB::table('tbl_app_user')
		->insert([
		'user_uniqueid'=>$userid,
		'app_user_fname'=>$first_name,    
		'app_user_lname'=>$last_name,    
		'app_user_email'=>$email,    
		'app_user_password'=>md5($password), 
		'app_user_gender'=> $gender ,     
		'app_user_dob'=>$dob,      
		'lr_governorate_area_id'=>$area_id,
		'app_user_lang'=>$lng_type,
		'admin_status'=>1,
		'app_user_created_time'=>$curDate,
		'app_user_updated_time'=>$curDate
		]);

		$sql_getuser_info=DB::table('tbl_app_user')
			->where('app_user_email','=',$email)                        
			->where('app_user_password','=',md5($password))
			->get();

		$user_uniqueid  =  $sql_getuser_info[0]->user_uniqueid;
		$app_user_fname = $sql_getuser_info[0]->app_user_fname;
		$app_user_lname = $sql_getuser_info[0]->app_user_lname;
		$app_user_email = $sql_getuser_info[0]->app_user_email;
		$app_user_gender = $sql_getuser_info[0]->app_user_gender;
		$app_user_dob = $sql_getuser_info[0]->app_user_dob;
		$lr_governorate_area_id = $sql_getuser_info[0]->lr_governorate_area_id;
		$app_user_phone = $sql_getuser_info[0]->app_user_phone;
		$app_user_lang = $sql_getuser_info[0]->app_user_lang;
		$admin_status = $sql_getuser_info[0]->admin_status;

		if($sql==true)
		{
			return ([
			'status' =>'200',
			'msg' => 'You have been successfully registered.',
			'user_data' =>[
				'user_uniqueid' => $user_uniqueid,
				'user_first_name' => $app_user_fname,
				'user_last_name' => $app_user_lname,
				'user_email' => $app_user_email,
				'user_gender' => $app_user_gender,
				'user_dob' => $app_user_dob,
				'user_area' => $lr_governorate_area_id,
				'user_phone' => $app_user_phone,
				'lng_type' => $app_user_lang
				]
			]);
		}
		else
		{
			return ([
			'status' =>'401',
			'msg' => 'Something went wrong, Please try again later.'
			]);
		}
	}
	else
	{
		return ([
			'status' =>'401',
			'msg' => 'All fields are required.'
			]);
	}
		} 
	}   // end of RegisterUser function

	public function LoginUser($request) // start of LoginUser function
	{
		$email = $request->email;
		$password = $request->password;
		$device_type = $request->device_type;
		$device_token = $request->device_token;
		if($email!='' && $password!='' && $device_type!='' && $device_token!='')
		{
			$sql1=DB::table('tbl_app_user')
			->where('app_user_email','=',$email)                        
			->where('app_user_password','=',md5($password))
			->get();
			if(count($sql1) > 0)
        	{
				$user_uniqueid  =  $sql1[0]->user_uniqueid;
				$app_user_fname = $sql1[0]->app_user_fname;
				$app_user_lname = $sql1[0]->app_user_lname;
				$app_user_email = $sql1[0]->app_user_email;
				$app_user_gender = $sql1[0]->app_user_gender;
				$app_user_dob = $sql1[0]->app_user_dob;
				$lr_governorate_area_id = $sql1[0]->lr_governorate_area_id;
				$app_user_phone = $sql1[0]->app_user_phone;
				$admin_status = $sql1[0]->admin_status;

				if($admin_status == 1)
				{
					return ([
					'status' =>'200',
					'msg' => 'Login successfully.',
					'user_data' =>[
					'user_uniqueid' => $user_uniqueid,
					'user_first_name' => $app_user_fname,
					'user_last_name' => $app_user_lname,
					'user_email' => $app_user_email,
					'user_gender' => $app_user_gender,
					'user_dob' => $app_user_dob,
					'user_area' => $lr_governorate_area_id,
					'user_phone' => $app_user_phone
					]
					
					]);
				
				 }
				 else
				 {
					return ([
					'status' =>'401',
					'msg' => 'Sorry! Your account has been deactivated, Please contact to our support team.'
					]);
				 }
			}
			else
			{
				return ([
				'status' =>'401',
				'msg' => 'Sorry! Entered E-Mail or Password is incorrect.'
				]);
			}
		}
		else
		{
			return ([
				'status' =>'401',
				'msg' => 'All fields are required.'
				]);
		}

	}  // end of LoginUser function 

	public function ForgotPassword($email) // start of ForgotPassword function
	{
		$sql=DB::table('tbl_app_user')
		->where('app_user_email','=',$email)
		->get(['admin_status','user_uniqueid','app_user_fname','app_user_lname']);

			if(count($sql) > 0)
        	{
				$admin_status = $sql[0]->admin_status;
				if($admin_status == 1)
				{
					$verify_token=getRandomString(20);
					$sql1= DB::table('tbl_app_user')
					->where('user_uniqueid', $sql[0]->user_uniqueid)
					->update(['app_user_forgot_token' =>$verify_token,'app_user_forgot_token_status' =>1]);

					$name = $sql[0]->app_user_fname.' '.$sql[0]->app_user_lname; 
					$sendemail = ForgotPasswordEmail($name,$email,$verify_token,'App');
					
					return ([
					'status' =>'200',
					'msg' => 'Check your email inbox to change your password.'
					]);  

				 }
				 else
				 {
					return ([
					'status' =>'401',
					'msg' => 'Sorry! Your account has been deactivated, Please contact to our support team.'
					]);
				 }
			}
			else
			{
			
				return ([
				'status' =>'401',
				'msg' => 'E-mail id does not exist'
				]);
			}
		

	}  // end of ForgotPassword function 

	public function changepassword($token) // start of changepassword function 
	{
		$sql_expiretoken = DB::table('tbl_app_user')
		->where([
			['app_user_forgot_token',$token],
			['app_user_forgot_token_status',0]
			])->get();
		$sql_validtoken = DB::table('tbl_app_user')->select('user_uniqueid')
				->where('app_user_forgot_token', $token)
				->where('app_user_forgot_token_status',1)->get();
		if(count($sql_validtoken)>0)
		{
		$token_status = '1';
		}
		else{
		$token_status = '3';
		}
		if(count($sql_expiretoken)>0)
		{
		$token_status = '2'; 
		}
		return view("Websrvc::changepassword")->with('token_status',$token_status)->with('token',$token);
	}  // end of changepassword function 

	public function changepasswordinsert($password,$token) // start of changepasswordinsert function 
	{
		if($token!=''){
			$sql_validtoken = DB::table('tbl_app_user')->select('user_uniqueid')
							->where('app_user_forgot_token', $token)->get();
		if(count($sql_validtoken)>0)
		{
			try
			{
				$sql_chgpass = DB::table('tbl_app_user')
				->where('app_user_forgot_token',$token)
				->update([
				'app_user_password'=> md5($password),
				'app_user_forgot_token_status'=>0
				]); 

				return ([
				'status' =>'200',
				'msg' => 'your password has been successfully changed.'
				]);
			}
			catch(Exception $e)
			{
			    return ([
				'status' =>'401',
				'msg' => 'Something went wrong, Please try again later.'
				]);
			}
		}
		else  
		{
			return ([
			'status' =>'401',
			'msg' => 'Sorry! invalid token'
			]); 
		}// check for invalid token
		}
		else
		{
			return ([
				'status' =>'401',
				'msg' => 'Something went wrong,Please try again later.'
				]); 
		}
	}  // end of changepasswordinsert function 

	public function GetPageLinks()  // start of GetPageLinks function 
	{

		return ([
			'status' =>'200',
			'msg' => 'Successfully Retrieve Information.',
			'aboutus' => url('/')."/websrvc/Aboutus"
			]);
	} // end of GetPageLinks function 

	public function Aboutus() // start of aboutus function 
    {
	  $about_us = DB::table('tbl_app_cms')->where('app_cms_id',1)->get(['app_cms_desp']);
	  return view("Websrvc::Aboutus")->with('about_us',$about_us[0]->app_cms_desp);
	}  // end of aboutus function 
	
	public function GetSupport() // start of GetSupport function 
	{
		$GetSupport_sql = DB::table('tbl_app_customer_service')
		->where('id',1)
		->get(['phone_no','app_customer_service_email']); 
		
		if(count($GetSupport_sql) > 0)
		{
			$phone_no = $GetSupport_sql[0]->phone_no;
			$email = $GetSupport_sql[0]->app_customer_service_email;
			return ([
				'status' =>'200',
				'msg' => 'Successfully Retrieve Information.',
				'phone' => $phone_no,
				'email' => $email
				]);
		}
		{
			return ([
				'status' =>'401',
				'msg' => 'Something went wrong, Please try again later.'
				]);
		}
		
		
	}  // end of GetSupport function    

	public function GetUserInfo($user_uniqueid) // start of GetUserInfo function 
	{  

	    $GetUserInfo_sql = DB::table('tbl_app_user')
							->where('user_uniqueid','=',$user_uniqueid)
							->get(['user_uniqueid','app_user_fname','app_user_lname','app_user_email','app_user_gender','app_user_dob','lr_governorate_area_id as user_area','app_user_phone','app_user_lang']);

		if(count($GetUserInfo_sql) > 0)
		{
			$user_uniqueid  =  $GetUserInfo_sql[0]->user_uniqueid;
			$app_user_fname = $GetUserInfo_sql[0]->app_user_fname;
			$app_user_lname = $GetUserInfo_sql[0]->app_user_lname;
			$app_user_email = $GetUserInfo_sql[0]->app_user_email;
			$app_user_gender = $GetUserInfo_sql[0]->app_user_gender;
			$app_user_dob = $GetUserInfo_sql[0]->app_user_dob;
			$lr_governorate_area_id = $GetUserInfo_sql[0]->user_area;
			$app_user_phone = $GetUserInfo_sql[0]->app_user_phone;
			$app_user_lang = $GetUserInfo_sql[0]->app_user_lang;

			$getAreaName = getAreaName($lr_governorate_area_id);

			$GetUseraddrInfo_sql = DB::table('tbl_app_user_address')
							->where('user_uniqueid','=',$user_uniqueid)
							->where('app_user_add_status',1)
							->get(['app_user_add_id','app_user_add_title','lr_governorate_area_id as user_addr_area','app_user_add_block','app_user_add_street','app_user_add_avenue','app_user_add_house','app_user_add_phone']);
	
			if(count($GetUseraddrInfo_sql) > 0)
			{
				$app_user_add_id = $GetUseraddrInfo_sql[0]->app_user_add_id;
				$app_user_add_title = $GetUseraddrInfo_sql[0]->app_user_add_title;
				$user_addr_area = $GetUseraddrInfo_sql[0]->user_addr_area;
				$app_user_add_block = $GetUseraddrInfo_sql[0]->app_user_add_block;
				$app_user_add_street = $GetUseraddrInfo_sql[0]->app_user_add_street;
				$app_user_add_avenue = $GetUseraddrInfo_sql[0]->app_user_add_avenue;
				$app_user_add_house = $GetUseraddrInfo_sql[0]->app_user_add_house;
				$app_user_add_phone = $GetUseraddrInfo_sql[0]->app_user_add_phone;

				$app_getAreaName = getAreaName($user_addr_area);

				return ([
					'status' =>'200',
					'msg' => 'Successfully Retrieve Information.',
					'user_data' =>[
						'user_uniqueid' => $user_uniqueid,
						'user_first_name' => $app_user_fname,
						'user_last_name' => $app_user_lname,
						'user_email' => $app_user_email,
						'user_gender' => $app_user_gender,
						'user_dob' => $app_user_dob,
						'user_area' => $lr_governorate_area_id,
						'add_area_name' => $getAreaName,
						'user_phone' => $app_user_phone,
						'lng_type' => $app_user_lang,
						'user_default_add' =>[   
							'add_id' => $app_user_add_id,
							'add_title' => $app_user_add_title,
							'add_area_id' => $user_addr_area,
							'add_area_name' => $app_getAreaName,
							'add_block' => $app_user_add_block,
							'add_street' => $app_user_add_street,
							'add_avenue' => $app_user_add_avenue,
							'add_house' => $app_user_add_house,
							'add_phone' => $app_user_add_phone
							]
					]
					
					]);
			}
			else
			{
				return ([
					'status' =>'200',
					'msg' => 'Successfully Retrieve Information.',
					'user_data' =>[
						'user_uniqueid' => $user_uniqueid,
						'user_first_name' => $app_user_fname,
						'user_last_name' => $app_user_lname,
						'user_email' => $app_user_email,
						'user_gender' => $app_user_gender,
						'user_dob' => $app_user_dob,
						'user_area' => $lr_governorate_area_id,
						'user_phone' => $app_user_phone,
						'lng_type' => $app_user_lang
					]
					
					]);
			}
			
		}
		{
			return ([
				'status' =>'401',
				'msg' => 'Something went wrong, Please try again later.'
				]);
		}
		
		
	}  // end of GetUserInfo function

	

	public function EditUserInfo($user_uniqueid,$first_name,$last_name,$gender,$dob,$phone,$lng_type) // start of EditUserInfo function 
	{

		if($user_uniqueid!='' || $first_name!='' || $last_name!='' || $gender!='' || $dob!='' || $phone!='' || $lng_type !='')
		{
			try
			{ 
				$sql_user_update = DB::table('tbl_app_user')->where('user_uniqueid','like',$user_uniqueid)->update([
					'app_user_fname' =>  $first_name,
					'app_user_lname' =>  $last_name,
					'app_user_phone' =>  $phone,
					'app_user_gender' =>  $gender,
					'app_user_dob' =>  $dob,
					'app_user_lang' =>  $lng_type	
				]);

				$GetUserInfo_sql = $sql1=DB::table('tbl_app_user')
							->where('user_uniqueid','=',$user_uniqueid) 
							->get();
		
				if(count($GetUserInfo_sql) > 0)
				{

					$user_uniqueid  =  $sql1[0]->user_uniqueid;
					$app_user_fname = $sql1[0]->app_user_fname;
					$app_user_lname = $sql1[0]->app_user_lname;
					$app_user_email = $sql1[0]->app_user_email;
					$app_user_gender = $sql1[0]->app_user_gender;
					$app_user_dob = $sql1[0]->app_user_dob;
					$lr_governorate_area_id = $sql1[0]->lr_governorate_area_id;
					$app_user_phone = $sql1[0]->app_user_phone;
					$app_user_lang = $sql1[0]->app_user_lang;

					return ([
					'status' =>'200',
					'msg' => 'Profile Updated Successfully.',
					'user_data' =>[
						'user_uniqueid' => $user_uniqueid,
						'user_first_name' => $app_user_fname,
						'user_last_name' => $app_user_lname,
						'user_email' => $app_user_email,
						'user_gender' => $app_user_gender,
						'user_dob' => $app_user_dob,
						'user_area' => $lr_governorate_area_id,
						'user_phone' => $app_user_phone,
						'lng_type' => $app_user_lang
						]
					]);
				}
				else
				{
					return ([
						'status' =>'401',
						'msg' => 'Something went wrong, Please try again later.'
						]);
				}

			}
			catch(Exception $e)
			{
				return ([
					'status' =>'401',
					'msg' => 'Something went wrong, Please try again later.'
					]);
			}
		}
		else
		{
            return ([
				'status' =>'401',
				'msg' => 'All fields are required.'
				]);
		}
	}  // end of EditUserInfo function

	public function UserLogin($mobile,$password,$dt)
	{
		
		return ([
	        	"status" => "200",
	        	"msg" => "Successfully retrieve information!",
	        	"mobile" => $mobile,
	        	"password" => $password
	        	]);



	}// end of user login function

	public function UpdatePassword($user_uniqueid,$old_password,$new_password,$confirm_password)  // end of UpdatePassword function
	{
		if($user_uniqueid !='' && $old_password !='' && $new_password !='' && $confirm_password)
		{
			$check_old_password = check_old_password($user_uniqueid,$old_password);
			if($check_old_password > 0)
			{
				if($new_password===$confirm_password)
				{
					try
					{
						$sql_update = DB::table('tbl_app_user')->where('user_uniqueid',$user_uniqueid)->update([
							'app_user_password' => md5($new_password)	
						]);

						return ([
							'status' =>'200',
							'msg' => 'Password updated successfully.'
							]);
					}
					catch(Exception $e)
					{
						return ([
							'status' =>'401',
							'msg' => 'Something went wrong, Please try again later.'
							]);
					}
					
				}
				else
				{
					return ([
						'status' =>'401',
						'msg' => 'Confirm password does not match.'
						]);
				}
			}
			else
			{
				return ([
					'status' =>'401',
					'msg' => 'Old password does not match.'
					]);
			}
		}
		else
		{
			return ([
				'status' =>'401',
				'msg' => 'All fields are required.'
				]);
		}
		
	}  // end of UpdatePassword function

	public function GetUserWallet($user_uniqueid)  // end of GetUserWallet function
	{
		if($user_uniqueid !='')
		{
			$GetUserWallet = DB::table('tbl_app_user_wallet')->where('user_uniqueid',$user_uniqueid)->get(['app_user_wallet_amount']);
			if(count($GetUserWallet) > 0)
			{
				$wallet_amount = $GetUserWallet[0]->app_user_wallet_amount;
				return ([
					'status' =>'200',
					'msg' => 'Successfully Retrieve Information.',
					'wallet_amount' => $wallet_amount
					]);
			}
			else
			{
				return ([
					'status' =>'200',
					'msg' => 'Successfully Retrieve Information.',
					'wallet_amount' => 0
					]);
			}
		}
		else
		{
			return ([
				'status' =>'401',
				'msg' => 'All fields are required.'
				]);
		}
		
	}  // end of GetUserWallet function

	
	public function OrderReportProblem($user_uniqueid,$order_id,$name,$email,$title,$comment)  // end of OrderReportProblem function
	{
		if($user_uniqueid !='' && $order_id !='' && $name !='' && $email !='' && $title !='')
		{
			$OrderReportProblem_sql = DB::table('tbl_app_order_report_problem')->insert([
										'user_uniqueid' => $user_uniqueid,
										'app_order_id' => $order_id,
										'app_report_problem_name' => $name,
										'app_report_problem_email' => $email,
										'app_report_problem_title' => $title,
										'app_report_problem_comment' => $comment
										]);
			
			if($OrderReportProblem_sql == true)
			{
				return ([
					'status' =>'200',
					'msg' => 'Successfully reported your feedback.'
					]);
			}
			else
			{
				return ([
					'status' =>'401',
					'msg' => 'Something went wrong, Please try again later.'
					]);
			}
		}
		else
		{
			return ([
				'status' =>'401',
				'msg' => 'All fields are required.'
				]);
		}
		
	}  // end of OrderReportProblem function

	public function AddAddress($user_uniqueid,$address_title,$area_id,$block,$street,$avenue,$house,$phone,$update_id)  // end of AddAddress function
	{
		$curDate = new \DateTime();
		if($update_id=='')
		{
			if($user_uniqueid !='' && $address_title !='' && $area_id !='' && $block !='' && $street !=''  && $avenue !='' && $house !='' && $phone !='')
			{
				$area_name_sql = DB::table('tbl_lr_governorate_area')->where('lr_governorate_area_id',$area_id)->get(['lr_governorate_area_name']);
	
				$is_address_add_before = DB::table('tbl_app_user_address')->where('user_uniqueid',$user_uniqueid)->count();
	
				if($is_address_add_before > 0)
				{  
					$add_status = 0;
				}
				else
				{   
					$add_status = 1;
				} 
	
				$AddAddress_sql = DB::table('tbl_app_user_address')->insert([
											'user_uniqueid' => $user_uniqueid,
											'app_user_add_title' => $address_title,
											'lr_governorate_area_id' => $area_id,
											'app_user_add_block' => $block,
											'app_user_add_street' => $street,
											'app_user_add_avenue' => $avenue,
											'app_user_add_house' => $house,
											'app_user_add_phone' => $phone,
											'app_user_add_created_time' => $curDate,
											'app_user_add_status' => $add_status
											]);
	
				$last_insert_id = DB::getPdo()->lastInsertId();
	
				
				
				if($AddAddress_sql == true)   
				{
					return ([
						'status' =>'200',
						'msg' => 'Address Added Successfully.',
						'add_address_info' =>[
							'add_id' => $last_insert_id,
							'add_area_name' => $area_name_sql[0]->lr_governorate_area_name, 
							'add_title' => $address_title,
							'add_area_id' => $area_id,
							'add_block' => $block,
							'add_street' => $street,
							'add_avenue' => $avenue,
							'add_house' => $house,
							'add_phone' => $phone
							]
						]);
				}
				else
				{
					return ([
						'status' =>'401',
						'msg' => 'Something went wrong, Please try again later.'
						]);
				}
			}
			else
			{
				return ([
					'status' =>'401',
					'msg' => 'All fields are required.'
					]);
			}
		}
		else
		{
			try
			{
				$getAreaName = getAreaName($area_id);

				$UpdateAddress_sql = DB::table('tbl_app_user_address')->where('app_user_add_id',$update_id)->update([
					'app_user_add_title' => $address_title,
					'lr_governorate_area_id' => $area_id,
					'app_user_add_block' => $block,
					'app_user_add_street' => $street,
					'app_user_add_avenue' => $avenue,
					'app_user_add_house' => $house,
					'app_user_add_phone' => $phone,
					'app_user_add_updated_time' => $curDate
					]);
	
					return ([
						'status' =>'200',
						'msg' => 'Address Updated Successfully.',
						'add_address_info' =>[
							'add_id' => $update_id,
							'add_area_name' => $getAreaName, 
							'add_title' => $address_title,
							'add_area_id' => $area_id,
							'add_block' => $block,
							'add_street' => $street,
							'add_avenue' => $avenue,
							'add_house' => $house,
							'add_phone' => $phone
							]
						]);
			}
			catch(Exception $e)
			{
				return ([
					'status' =>'401',
					'msg' => 'Something went wrong, Please try again later.'
					]);
			}

			
		}
	
		
	}  // end of AddAddress function

	public function GetAddressList($user_uniqueid) // start of GetUserInfo function 
	{
		$GetAddressList_sql = $sql1=DB::table('tbl_app_user_address')
							->where('user_uniqueid','=',$user_uniqueid) 
							->get();
			$address_info_data =[];
			foreach($GetAddressList_sql as $val)
			{           
			$app_user_add_id = $val->app_user_add_id;
			$address_title = $val->app_user_add_title;
			$area_id = $val->lr_governorate_area_id;
			$block = $val->app_user_add_block;
			$street = $val->app_user_add_street;
			$avenue = $val->app_user_add_avenue;
			$house = $val->app_user_add_house;
			$phone = $val->app_user_add_phone;
			$status = $val->app_user_add_status;

			$getAreaName = getAreaName($area_id);

			$address_info_data[] = [
				'add_id' => $app_user_add_id,
				'add_title' => $address_title,
				'add_area_id' => $area_id,
				'add_area_name' => $getAreaName,
				'add_block' => $block,
				'add_street' => $street,
				'add_avenue' => $avenue,
				'add_house' => $house,
				'add_phone' => $phone,
				'add_status' => $status
				];
			}
			
			return ([
				'status' => '200',
				'msg' => 'Successfully Retrieve Information.',
				'address_info' => $address_info_data
			]);
		
		
	}  // end of GetUserInfo function

	public function MarkAsDefaultAdd($user_uniqueid,$address_id) // start of GetUserInfo function 
	{
		try
		{

			$MarkAsDefaultAddr_sql1 = $sql1=DB::table('tbl_app_user_address')
							->where('user_uniqueid','like',$user_uniqueid)
							->update([
								'app_user_add_status' => 0
							]);

			$MarkAsDefaultAddr_sql = $sql1=DB::table('tbl_app_user_address')
							->where('user_uniqueid','like',$user_uniqueid)
							->where('app_user_add_id',$address_id) 
							->update([
								'app_user_add_status' => 1
							]);

			return ([
				'status' => '200',
				'msg' => 'Marked As Default Address.'
			]);
		}
		catch(Exception $e)
		{
			return ([
				'status' => '401',
				'msg' => 'Something went wrong, Please try again later.'
			]);
		}
		
	}  // end of GetUserInfo function   

	public function GetPlanDietList($type) // start of GetPlanDietList function 
	{
		if($type=='PACKAGES')
		{
			$GetPlanDietList_sql = $sql1=DB::table('tbl_lr_vendor_package')
			->where('admin_status','=',1)
			->get(['vendor_plan_id','lr_package_id','package_name','package_description','package_price']);

			if(count($GetPlanDietList_sql) > 0)
			{
				$plan_info = [];
				foreach($GetPlanDietList_sql as $planval)
				{
					$no_of_plan_days = DB::table('tbl_lr_vendor_plandetail')->where('vendor_plan_id',$planval->vendor_plan_id)->count();

					$GetPlandetails_sql = $sql1=DB::table('tbl_lr_vendor_plan as t1')
							->join('tbl_lr_userdetail as t2','t1.lr_user_id','t2.lr_user_userid')
							->where('vendor_plan_id','=',$planval->vendor_plan_id)
							->get(['vendor_plan_meals','vendor_plan_snacks','t2.lr_user_userid','lr_userdetail_centrename']);

					if(!count($GetPlandetails_sql) > 0)
					{
						return ([
							'status' => '200',
							'msg' => 'No Records found.',
							'plan_info' => array()
								]);
					}
					
					$plan_info[] = [   
						'plan_id' => $planval->lr_package_id,
						'plan_name' => $planval->package_name,
						'plan_diet_center_id' => $GetPlandetails_sql[0]->lr_user_userid,
						'plan_diet_center_name' => $GetPlandetails_sql[0]->lr_userdetail_centrename,
						'plan_image' => url('/public/app/image/defaultplanimage.jpg'),
						'plan_meals_count' => $GetPlandetails_sql[0]->vendor_plan_meals,
						'plan_snacks_count' => $GetPlandetails_sql[0]->vendor_plan_snacks,
						'plan_days_count' => $no_of_plan_days,
						'plan_cost' => $planval->package_price
						];
				}

				return ([
					'status' => '200',
					'msg' => 'Successfully Retrieve Information.',
					'plan_info' => $plan_info
				]);
			}
			else
			{
				return ([
					'status' => '200',
					'msg' => 'No Records found.',
					'plan_info' => array()
				]);
			}
		}
		else
		{
			$GetPlanDietList_sql = $sql1=DB::table('tbl_lr_vendor_plan as t1')
			->join('tbl_lr_userdetail as t2','t1.lr_user_id','t2.lr_user_userid')
							->where('t1.status','=',1) 
							->where('t1.admin_status','=',1) 
							->where('vendor_plan_type','=',$type)
							->get(['vendor_plan_id','vendor_plan_name','vendor_plan_meals','vendor_plan_snacks','plan_cost','t2.lr_user_userid','lr_userdetail_centrename']);

			if(count($GetPlanDietList_sql) > 0)
			{
				$plan_info = [];
				foreach($GetPlanDietList_sql as $planval)
				{
					$no_of_plan_days = DB::table('tbl_lr_vendor_plandetail')->where('vendor_plan_id',$planval->vendor_plan_id)->count();

				$plan_info[] = [   
					'plan_id' => $planval->vendor_plan_id,
					'plan_name' => $planval->vendor_plan_name,
					'plan_diet_center_id' => $planval->lr_user_userid,
					'plan_diet_center_name' => $planval->lr_userdetail_centrename,
					'plan_image' => url('/public/app/image/defaultplanimage.jpg'),
					'plan_meals_count' => $planval->vendor_plan_meals,
					'plan_snacks_count' => $planval->vendor_plan_snacks,
					'plan_days_count' => $no_of_plan_days,
					'plan_cost' => $planval->plan_cost
					];
				}

				return ([
					'status' => '200',
					'msg' => 'Successfully Retrieve Information.',
					'plan_info' => $plan_info
				]);
			}
			else
			{
				return ([
					'status' => '200',
					'msg' => 'No Records found.',
					'plan_info' => array()
				]);
			}
		}
		
		
	}  // end of GetPlanDietList function

	public function GetPlanDietDetails($plan_id) // start of GetPlanDietDetails function 
	{

			$GetPlanDietDetails_sql = DB::table('tbl_lr_vendor_plan')
							->where('vendor_plan_id','=',$plan_id)
							->get(['vendor_plan_name','vendor_plan_offdays','vendor_plan_menu_type']); // sql to get plan details
			
			$plan_detail_date_sql = DB::table('tbl_lr_vendor_plandetail')->where('vendor_plan_id',$plan_id)->distinct('vendor_plandetail_date')->get(['vendor_plandetail_date','lr_unique_id']);  // sql to get plan details date wise
			

			$plan_detail_date_wise = [];

			foreach($plan_detail_date_sql as $date) // loop for plan detail date nwise
			{
				$menucategory =  DB::table('tbl_lr_vendor_plandetail')->where('vendor_plan_id',$plan_id)->where('vendor_plandetail_date',$date->vendor_plandetail_date)->distinct('lr_menucategory_id')->get(['lr_menucategory_id']); //sql to get menu category

				

				$menucat_array = []; // array to hold menu details
				
				foreach($menucategory as $menu_cat_val) // loop for menu category
				{  
					$meal = DB::table('tbl_lr_vendor_plandetail')->where('vendor_plan_id',$plan_id)->where('vendor_plandetail_date',$date->vendor_plandetail_date)->where('lr_menucategory_id',$menu_cat_val->lr_menucategory_id)->get(['lr_meal_id']);

					$meal_name_sql = DB::table('tbl_lr_meal')->where('lr_meal_id',$meal[0]->lr_meal_id)->get(['lr_meal_name']);

					$meal_array = [];  // array to hold meal details

					foreach($meal as $meal_val)
					{
						$meal_array[] = [
							'meal_id' => $meal_val->lr_meal_id,
							'meal_name' => $meal_name_sql[0]->lr_meal_name
						];
					}

					

					$menuname_sql = DB::table('tbl_lr_menu_category')->where('lr_category_id',$menu_cat_val->lr_menucategory_id)->get(['lr_category_name']);
					
					 $menucat_array[] = [
						 'menu_id' => $menu_cat_val->lr_menucategory_id,
						 'menu_category' => $menuname_sql[0]->lr_category_name,
						 'meal_data' => $meal_array
					 ];

					$plan_detail_date_wise[] = [  
						'calender_id' => $date->lr_unique_id,
						'calender_date' => $date->vendor_plandetail_date,
						'menu_data' => $menucat_array
						];
				}
				
			}

			$plan_detail = [];
			$plan_detail[] = [  
				
				];

			return ([
				'status' => '200',
				'msg' => 'Successfully Retrieve Information.',
				'plan_detail' =>[
				'plan_id' => $plan_id,
				'plan_name' => $GetPlanDietDetails_sql[0]->vendor_plan_name,
				'plan_offdays' => $GetPlanDietDetails_sql[0]->vendor_plan_offdays,
				'plan_menutype' => $GetPlanDietDetails_sql[0]->vendor_plan_menu_type,
				'calender_detail' => $plan_detail_date_wise
				],
				
				
			]);

			
	}  // end of GetPlanDietDetails function


	public function checkout($user_info,$calender_detail,$user_uniqueid,$plan_id,$plan_name,$diet_center_name,$menu_type,$plan_days_off) // start of checkout function 
	{   
	
		  
		DB::beginTransaction();

		try {
			$checkout_sql = DB::table('tbl_app_pre_order')->insert([
				"user_uniqueid" =>  $user_uniqueid,
				"vendor_plan_id" =>  $plan_id,
				"vendor_plan_name" =>  $plan_name,
				"lr_userdetail_centrename" =>  $diet_center_name,
				"vendor_plan_menu_type" =>  $menu_type,
				"vendor_plan_offdays" =>  $plan_days_off,
				"app_pre_order_name" =>  $user_info[0]['user_name'],
				"app_pre_order_email" =>  $user_info[0]['user_email'],
				"app_pre_order_timing" =>  $user_info[0]['user_timing'],
				"app_pre_order_addr_id" =>  $user_info[0]['user_address'][0]['user_address_id'],
				"app_pre_order_addr_title" =>  $user_info[0]['user_address'][0]['user_address_title'],
				"app_pre_order_addr_areaid" =>  $user_info[0]['user_address'][0]['user_address_area_id'],
				"app_pre_order_addr_areaname" =>  $user_info[0]['user_address'][0]['user_address_name'],
				"app_pre_order_addr_block" =>  $user_info[0]['user_address'][0]['user_address_block'],
				"app_pre_order_addr_street" =>  $user_info[0]['user_address'][0]['user_address_street'],
				"app_pre_order_addr_avenue" =>  $user_info[0]['user_address'][0]['user_address_avenue'],
				"app_pre_order_addr_house" =>  $user_info[0]['user_address'][0]['user_address_house'],
				"app_pre_order_addr_phone" =>  $user_info[0]['user_address'][0]['user_address_phone']
				
			]);
			$last_insert_id = DB::getPdo()->lastInsertId();

			foreach($calender_detail as $cal_val)
			{  
				$sql_insert_calender = DB::table('tbl_app_pre_order_calender')->insert([
					'tbl_app_pre_order' => $last_insert_id,
					'vendor_plandetail_date' => $cal_val['calender_date']
				]);

				if($sql_insert_calender == true)
				{   
					$last_insert_id = DB::getPdo()->lastInsertId();
					foreach($cal_val['menu_data'] as $menu_data_val)
					{   
						DB::table('tbl_app_preorder_calender_menu')->insert([
							'pre_order_calender_id' => $last_insert_id,
							'lr_category_id' => $menu_data_val['menu_id'] ,
							'lr_category_name' => $menu_data_val['menu_category']
						]);
	
						$last_insert_id = DB::getPdo()->lastInsertId();
						foreach($menu_data_val['meal_data'] as $meal_data_val)
						{
							DB::table('tbl_app_preorder_calender_menu_meal')->insert([
								'preorder_calender_menu_id' => $last_insert_id,
								'lr_meal_id' => $meal_data_val['meal_id'],
								'lr_meal_name' => $meal_data_val['meal_name'],
								'lr_meal_description' => $meal_data_val['meal_description']
							]);
						}
	
	
					}
				}

				
			}
			
		
		DB::commit();

			return ([
				'status' => '200',
				'msg' => 'Data inserted successfully.'
			]);

			
		} catch (\Exception $e) {
			DB::rollback();
			return ([
				'status' => '200',
				'msg' => 'Something went wrong, Please try again later.'
			]);
		}
							
	}  // end of checkout function

	public function GetServiceFee($user_uniqueid)
	{
		$service_fee = 100;
		$GetUserWallet = DB::table('tbl_app_user_wallet')->where('user_uniqueid',$user_uniqueid)->get(['app_user_wallet_amount']);
			if(count($GetUserWallet) > 0)
			{
				$wallet_amount = $GetUserWallet[0]->app_user_wallet_amount;
				return ([
					'status' =>'200',
					'msg' => 'Successfully Retrieve Information.',
					'wallet_amount' => $wallet_amount,
					'service_fee' => $service_fee
					]);
			}
			else
			{
				return ([
					'status' =>'200',
					'msg' => 'Successfully Retrieve Information.',
					'wallet_amount' => 0,
					'service_fee' => $service_fee
					]);
			}

	}

	public function GetfilterDietCenterList($type) // start of GetPlanDietList function 
	{
		if($type=='PACKAGES')
		{
			$GetPlanDietList_sql = $sql1=DB::table('tbl_lr_vendor_package')
			->where('admin_status','=',1)
			->get(['vendor_plan_id']);

			if(count($GetPlanDietList_sql) > 0)
			{
				$diet_center_info = [];
				foreach($GetPlanDietList_sql as $planval)
				{
					$GetPlandetails_sql = $sql1=DB::table('tbl_lr_vendor_plan as t1')
							->join('tbl_lr_userdetail as t2','t1.lr_user_id','t2.lr_user_userid')
							->where('vendor_plan_id','=',$planval->vendor_plan_id)
							->get(['t2.lr_user_userid','lr_userdetail_centrename']);

					if(!count($GetPlandetails_sql) > 0)
					{
						return ([
							'status' => '200',
							'msg' => 'No Records found.',
							'diet_center_info' => array()
								]);
					}
					
					$diet_center_info[] = [   
						'plan_diet_center_id' => $GetPlandetails_sql[0]->lr_user_userid,
					    'plan_diet_center_name' => $GetPlandetails_sql[0]->lr_userdetail_centrename
						];
				}

				return ([
					'status' => '200',
					'msg' => 'Successfully Retrieve Information.',
					'diet_center_info' => $diet_center_info
				]);
			}
			else
			{
				return ([
					'status' => '200',
					'msg' => 'No Records found.',
					'diet_center_info' => array()
				]);
			}
		}
		else
		{
			$GetfilterDietCenterList = $sql1=DB::table('tbl_lr_vendor_plan as t1')
			->join('tbl_lr_userdetail as t2','t1.lr_user_id','t2.lr_user_userid')
							->where('t1.status','=',1) 
							->where('t1.admin_status','=',1) 
							->where('vendor_plan_type','=',$type)
							->distinct('t1.lr_user_id')
							->get(['t2.lr_user_userid','lr_userdetail_centrename']);

			if(count($GetfilterDietCenterList) > 0)
			{
				$diet_center_info = [];
				foreach($GetfilterDietCenterList as $planval)
				{

				$diet_center_info[] = [ 
					'plan_diet_center_id' => $planval->lr_user_userid,
					'plan_diet_center_name' => $planval->lr_userdetail_centrename
					];
				}

				return ([
					'status' => '200',
					'msg' => 'Successfully Retrieve Information.',
					'diet_center_info' => $diet_center_info
				]);
			}
			else
			{
				return ([
					'status' => '200',
					'msg' => 'No Records found.',
					'diet_center_info' => array()
				]);
			}
		}
		
		
	}  // end of GetPlanDietList function

	public function GetFilterPlanList($type,$vendor_id) // start of GetFilterPlanList function 
	{
		if($type=='PACKAGES')
		{
			$GetPlanDietList_sql = $sql1=DB::table('tbl_lr_vendor_package')
			->where('admin_status','=',1)
			->get(['vendor_plan_id']);

			if(count($GetPlanDietList_sql) > 0)
			{
				$diet_center_info = [];
				foreach($GetPlanDietList_sql as $planval)
				{
					$GetPlandetails_sql = $sql1=DB::table('tbl_lr_vendor_plan as t1')
							->join('tbl_lr_userdetail as t2','t1.lr_user_id','t2.lr_user_userid')
							->where('vendor_plan_id','=',$planval->vendor_plan_id)
							->get(['t2.lr_user_userid','lr_userdetail_centrename']);

					if(!count($GetPlandetails_sql) > 0)
					{
						return ([
							'status' => '200',
							'msg' => 'No Records found.',
							'diet_center_info' => array()
								]);
					}
					
					$diet_center_info[] = [   
						'plan_diet_center_id' => $GetPlandetails_sql[0]->lr_user_userid,
					    'plan_diet_center_name' => $GetPlandetails_sql[0]->lr_userdetail_centrename
						];
				}

				return ([
					'status' => '200',
					'msg' => 'Successfully Retrieve Information.',
					'diet_center_info' => $diet_center_info
				]);
			}
			else
			{
				return ([
					'status' => '200',
					'msg' => 'No Records found.',
					'diet_center_info' => array()
				]);
			}
		}
		else
		{
			$GetFilterPlanList_Sql = DB::table('tbl_lr_vendor_plan')
							->where('vendor_plan_type','=',$type)
							->where('lr_user_id',$vendor_id)
							->get(['vendor_plan_id','vendor_plan_name']);

			if(count($GetFilterPlanList_Sql) > 0)
			{
				$plan_info = [];
				foreach($GetFilterPlanList_Sql as $planval)
				{

				$plan_info[] = [ 
					'plan_id' => $planval->vendor_plan_id,
					'plan_name' => $planval->vendor_plan_name
					];
				}

				return ([
					'status' => '200',
					'msg' => 'Successfully Retrieve Information.',
					'plan_info' => $plan_info
				]);
			}
			else
			{
				return ([
					'status' => '200',
					'msg' => 'No Records found.',
					'plan_info' => array()
				]);
			}
		}

	}   // end of GetFilterPlanList function

	public function DeleteAddress($add_id)   // start of DeleteAddress function
	{
		$DeleteAddress_Sql = DB::table('tbl_app_user_address')->where('app_user_add_id',$add_id)->delete();

		if($DeleteAddress_Sql==true)
		{
			return ([
				'status' => '200',
				'msg' => 'Address Deleted Successfully.'
			]);
		}
		else
		{
			return ([
				'status' => '401',
				'msg' => 'Something went wrong, Please try again later.'
			]);
		}

	}   // end of DeleteAddress function

	public function CurrentOrder($add_id)   // start of CurrentOrder function
	{
		$CurrentOrder_Sql = DB::table('tbl_app_user_address')->where('app_user_add_id',$add_id)->delete();

		if($CurrentOrder_Sql==true)
		{
			return ([
				'status' => '200',
				'msg' => 'Address Deleted Successfully.'
			]);
		}
		else
		{
			return ([
				'status' => '401',
				'msg' => 'Something went wrong, Please try again later.'
			]);
		}

	}   // end of CurrentOrder function
	

	}// end of class
