<?php 

return [
    'welcome' => 'Welcome, this is Websrvc module.'
];
