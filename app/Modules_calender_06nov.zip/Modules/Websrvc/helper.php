<?php

    function check_old_password($user_uniqueid,$old_password)
        {
           $is_exists = DB::table('tbl_app_user')->where('user_uniqueid',$user_uniqueid)->where('app_user_password',md5($old_password))->count();
           return $is_exists;
        }

    function getAreaName($area_id)
    {
       $area_name_sql = DB::table('tbl_lr_governorate_area')->where('lr_governorate_area_id',$area_id)->get(['lr_governorate_area_name']);
       return $area_name_sql[0]->lr_governorate_area_name;
    }
?>