<?php

echo trans('Websrvc::example.welcome');