<?php

namespace App\Modules\Websrvc\Controllers;
use App\Modules\Websrvc\Models\Websrvc;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Response;
class WebsrvcController extends Controller
{
  public function __construct()
  {
       
  }
   public function AreaList(Request $request) // Area List
    {
      if($request->isMethod('POST'))  //start of post
      {
          $ModelCalled = new Websrvc;
          $AreaList = $ModelCalled->AreaList();
          return response()->json($AreaList);
      }
      else
      {
         return response()->json(
          [
          'status' =>'401',
          'msg' => 'Invalid request, please try again.'
          ]);
      }
    } // end of area list function

    public function RegisterUser(Request $request) // start of register function 
    {
      if($request->isMethod('post'))
      {
        $ModelCalled = new Websrvc;
        $RegisterUser = $ModelCalled->RegisterUser($request);
        return response()->json($RegisterUser);
      }
      else
      {
        return response()->json(
          [
          'status' =>'401',
          'msg' => 'Invalid request, please try again.'
          ]);
      }
    }  // end of register function 

    public function LoginUser(Request $request) // start of LoginUser function 
    {
      if($request->isMethod('post'))
      {
        $ModelCalled = new Websrvc;
        $LoginUser = $ModelCalled->LoginUser($request);
        return response()->json($LoginUser);
      }
      else
      {
        return response()->json(
          [
          'status' =>'401',
          'msg' => 'Invalid request, please try again.'
          ]);
      }
    } // end of LoginUser function 

    public function ForgotPassword(Request $request) // start of ForgotPassword function 
    {
      if($request->isMethod('post'))
      {
       $email =  $request->email;
        if($email!='')
	    	{
          $ModelCalled = new Websrvc;
          $ForgotPassword = $ModelCalled->ForgotPassword($email);
          return response()->json($ForgotPassword);
        }
        else
        {
          return ([
            'status' =>'401',
            'msg' => 'Please enter your e-mail address.'
            ]);
        }
      }
      else
      {
        return response()->json(
          [
          'status' =>'401',
          'msg' => 'Invalid request, please try again.'
          ]);
      }
    } // end of ForgotPassword function 

    public function UserLogin(Request $request)
    {
      if($request->isMethod('POST'))//start of post
      {
        $mobile = trim($request->mobile);
        $password = trim($request->password);
        $dt = 'datetime';
        if($password != "" && $password != "")
        {
          $ModelCalled = new Websrvc;
          $UserLogin = $ModelCalled->UserLogin($mobile,$password,$dt);
          return response()->json($UserLogin);

        }
        else
        {
          return response()->json(
                [
                'status' =>'401',
                'msg' => 'All fields required.'
                ]);
        }

       
      }
      else
      {
         return response()->json(
                [
                'status' =>'401',
                'msg' => 'Invalid request, please try again.'
                ]);
      }
    }

    public function changepassword($token)  // start of changepassword function 
    {
      if($token!='')
      {    $ModelCalled = new Websrvc;
           $changepassword = $ModelCalled->changepassword($token);
           return $changepassword;
      }
      else
      {
          $token_status = '3';
          return view("Websrvc::changepassword")->with('token',$token);
      }
    }  // end of changepassword function 

    public function changepasswordinsert(Request $request) // start of changepasswordinsert function 
    {
      if($request->isMethod('POST'))
      {       
      $password = $request->password;
      $token = $request->user_id;

       $ModelCalled = new Websrvc;
       $changepasswordinsert = $ModelCalled->changepasswordinsert($password,$token);
       return response()->json($changepasswordinsert);
      } // check for method post
      else
      {
      return response()->json(
      [
      'status' =>'401',
      'msg' => 'Invalid Request'
      ]); 
      }
    }  // end of changepasswordinsert function 

    public function Aboutus(Request $request) // start of Aboutus function 
    {
     
       $ModelCalled = new Websrvc;
       $Aboutus = $ModelCalled->Aboutus();
       return $Aboutus;

    }  // end of aboutus function 

    public function GetPageLinks(Request $request) // start of aboutus function 
    {
      if($request->isMethod('POST'))
      { 
       $ModelCalled = new Websrvc;
       $GetPageLinks = $ModelCalled->GetPageLinks();
       return response()->json($GetPageLinks);
      } // check for method post
      else
      {
      return response()->json(
      [
      'status' =>'401',
      'msg' => 'Invalid Request'
      ]); 
      }
    }  // end of aboutus function 

    public function GetSupport(Request $request) // start of GetSupport function 
    {
      if($request->isMethod('POST'))
      { 
       $ModelCalled = new Websrvc;
       $GetSupport = $ModelCalled->GetSupport();
       return response()->json($GetSupport);
      } // check for method post
      else
      {
      return response()->json(
      [
      'status' =>'401',
      'msg' => 'Invalid Request'
      ]); 
      }
    }  // end of GetSupport function   

    public function GetUserInfo(Request $request) // start of GetUserInfo function 
    { 
      if($request->isMethod('POST'))
      { 
       $user_uniqueid = $request->user_uniqueid;
       $ModelCalled = new Websrvc;
       $GetUserInfo = $ModelCalled->GetUserInfo($user_uniqueid);
       return response()->json($GetUserInfo);
      } // check for method post
      else
      {
      return response()->json(
      [
      'status' =>'401',
      'msg' => 'Invalid Request'
      ]); 
      }
    }  // end of GetUserInfo function 

    public function EditUserInfo(Request $request) // start of EditUserInfo function 
    { 
      if($request->isMethod('POST'))
      { 
       $user_uniqueid = $request->user_uniqueid;
       $first_name = $request->first_name;
       $last_name = $request->last_name;
       $gender = $request->gender;
       $dob = $request->dob;  
       $phone = $request->phone;
       $lng_type = $request->lng_type;

       $ModelCalled = new Websrvc;
       $EditUserInfo = $ModelCalled->EditUserInfo($user_uniqueid,$first_name,$last_name,$gender,$dob,$phone,$lng_type);
       return response()->json($EditUserInfo);
      } // check for method post
      else
      {
      return response()->json(
      [
      'status' =>'401',
      'msg' => 'Invalid Request'
      ]); 
      }
    }  // end of EditUserInfo function   

    public function UpdatePassword(Request $request) // start of UpdatePassword function 
    { 
      if($request->isMethod('POST'))
      { 
       $user_uniqueid = $request->user_uniqueid;
       $old_password = $request->old_password;
       $new_password = $request->new_password;
       $confirm_password = $request->confirm_password;

       $ModelCalled = new Websrvc;
       $UpdatePassword = $ModelCalled->UpdatePassword($user_uniqueid,$old_password,$new_password,$confirm_password);
       return response()->json($UpdatePassword);
      } // check for method post
      else
      {
      return response()->json(
      [
      'status' =>'401',
      'msg' => 'Invalid Request'
      ]); 
      }
    }  // end of UpdatePassword function 

    public function GetUserWallet(Request $request) // start of GetUserWallet function 
    { 
      if($request->isMethod('POST'))
      { 
       $user_uniqueid = $request->user_uniqueid;

       $ModelCalled = new Websrvc;
       $GetUserWallet = $ModelCalled->GetUserWallet($user_uniqueid);
       return response()->json($GetUserWallet);
      } // check for method post
      else
      {
      return response()->json(
      [
      'status' =>'401',
      'msg' => 'Invalid Request'
      ]); 
      }
    }  // end of GetUserWallet function   

    public function OrderReportProblem(Request $request) // start of OrderReportProblem function 
    { 
      if($request->isMethod('POST'))
      { 
       $user_uniqueid = $request->user_uniqueid;
       $order_id = $request->order_id;
       $name = $request->name;
       $email = $request->email;
       $title = $request->title;
       $comment = $request->comment;

       $ModelCalled = new Websrvc;
       $OrderReportProblem = $ModelCalled->OrderReportProblem($user_uniqueid,$order_id,$name,$email,$title,$comment);
       return response()->json($OrderReportProblem);
      } // check for method post
      else
      {
      return response()->json(
      [
      'status' =>'401',
      'msg' => 'Invalid Request'
      ]); 
      }
    }  // end of OrderReportProblem function   

    public function AddAddress(Request $request) // start of AddAddress function 
    { 
      if($request->isMethod('POST'))
      { 
       $update_id = $request->address_id;
       $user_uniqueid = $request->user_uniqueid;
       $address_title = $request->address_title;
       $area_id = $request->area_id;
       $block = $request->block;
       $street = $request->street;
       $avenue = $request->avenue;
       $house = $request->house;
       $phone = $request->phone;

       $ModelCalled = new Websrvc;
       $AddAddress = $ModelCalled->AddAddress($user_uniqueid,$address_title,$area_id,$block,$street,$avenue,$house,$phone,$update_id);
       return response()->json($AddAddress);
      } // check for method post
      else
      {
      return response()->json(
      [
      'status' =>'401',
      'msg' => 'Invalid Request'
      ]); 
      }
    }  // end of AddAddress function 
 
   

    public function GetAddressList(Request $request) // start of GetAddressList function 
    { 
      if($request->isMethod('POST'))
      { 
       $user_uniqueid = $request->user_uniqueid;
       $ModelCalled = new Websrvc;
       $GetAddressList = $ModelCalled->GetAddressList($user_uniqueid);
       return response()->json($GetAddressList);
      } // check for method post
      else
      {
      return response()->json(
      [
      'status' =>'401',
      'msg' => 'Invalid Request'
      ]); 
      }
    }  // end of GetAddressList function 

    public function MarkAsDefaultAdd(Request $request) // start of MarkAsDefaultAddr function 
    { 
      if($request->isMethod('POST'))
      { 
       $user_uniqueid = $request->user_uniqueid;
       $address_id = $request->address_id;
       if($user_uniqueid != "" && $address_id != "")
       {
          $ModelCalled = new Websrvc;
          $MarkAsDefaultAdd = $ModelCalled->MarkAsDefaultAdd($user_uniqueid,$address_id);
          return response()->json($MarkAsDefaultAdd);
       }
       else
       {
        return response()->json(
          [
          'status' =>'401',
          'msg' => 'All field are required.'
          ]);
       }
     
      } // check for method post
      else
      {
      return response()->json(
      [
      'status' =>'401',
      'msg' => 'Invalid Request'
      ]); 
      }
    }  // end of MarkAsDefaultAddr function   

    public function GetPlanDietList(Request $request) // start of GetPlanDietList function 
    { 
      if($request->isMethod('POST'))
      { 
       $type = $request->type; // MONTHLY,PACKAGE,WEEKLY
      if($type != "")
      {
        $ModelCalled = new Websrvc;
        $GetPlanDietList = $ModelCalled->GetPlanDietList($type);
        return response()->json($GetPlanDietList);
      }
      else
      {
        return response()->json(
          [
          'status' =>'401',
          'msg' => 'All field are required.'
          ]);
      }

      } // check for method post
      else
      {
        return response()->json(
        [
        'status' =>'401',
        'msg' => 'Invalid Request'
        ]); 
      }
    }  // end of GetPlanDietList function

    public function GetPlanDietDetails(Request $request) // start of GetPlanDietDetails function 
    { 
      if($request->isMethod('POST'))
      { 
       $plan_id = $request->plan_id;
       if($plan_id!='')
       {
        $ModelCalled = new Websrvc;
        $GetPlanDietDetails = $ModelCalled->GetPlanDietDetails($plan_id);
        return response()->json($GetPlanDietDetails);
       }
       else  
       {
        return response()->json(
          [
          'status' =>'401',
          'msg' => 'All field are required.'
          ]);
       }
       
      } // check for method post
      else
      {
      return response()->json(
      [
      'status' =>'401',
      'msg' => 'Invalid Request'
      ]); 
      }
    }  // end of GetPlanDietDetails function

    public function checkout(Request $request) // start of checkout function 
    { 
      if($request->isMethod('POST'))
      {       
         $user_info = array();
         $user_address = array();   
         $calender_detail = array();   
         $user_uniqueid = $request->user_uniqueid; 
         $plan_id = $request->plan_id; 
         $plan_name  = $request->plan_name ; 
         $diet_center_name = $request->diet_center_name; 
         $menu_type = $request->menu_type; 
         $plan_days_off = $request->plan_days_off;
         $user_info = $request->user_info;
         $calender_detail = $request->calender_detail;
        

          if( count($user_info) > 0 && count($calender_detail) > 0 && $plan_id!='' && $plan_name!='' && $diet_center_name!='' && $menu_type!='' && $user_uniqueid != '' && $plan_days_off!=''  )
          {
            $ModelCalled = new Websrvc;
            $checkout = $ModelCalled->checkout($user_info,$calender_detail,$user_uniqueid,$plan_id,$plan_name,$diet_center_name,$menu_type,$plan_days_off);
            return response()->json($checkout);
          }
          else  
          {
            return response()->json(
              [
              'status' =>'401',
              'msg' => 'All field are required.'
              ]);
          }
       
      } // check for method post
      else
      {
      return response()->json(
      [
      'status' =>'401',
      'msg' => 'Invalid Request'
      ]); 
      }
    }  // end of checkout function

    public function GetServiceFee(Request $request)
    {
      if($request->isMethod('post'))
      {
        $user_uniqueid = $request->user_uniqueid;
        if($user_uniqueid!='')
        {
          $ModelCalled = new Websrvc;
          $GetServiceFee = $ModelCalled->GetServiceFee($user_uniqueid);
          return response()->json($GetServiceFee);
        }
        else
        {
          return response()->json(
            [
            'status' =>'401',
            'msg' => 'All field are required.'
            ]);
        }
      } // check for method post
      else
      {
      return response()->json(
      [
      'status' =>'401',
      'msg' => 'Invalid Request'
      ]); 
      }
    }

    public function GetfilterDietCenterList(Request $request) // start of GetfilterDietCenterList function 
    { 
      if($request->isMethod('POST'))
      { 
       $type = $request->type; // MONTHLY,PACKAGE,WEEKLY
      if($type != "")
      {
        $ModelCalled = new Websrvc;
        $GetfilterDietCenterList = $ModelCalled->GetfilterDietCenterList($type);
        return response()->json($GetfilterDietCenterList);
      }
      else
      {
        return response()->json(
          [
          'status' =>'401',
          'msg' => 'All field are required.'
          ]);
      }

      } // check for method post
      else
      {
        return response()->json(
        [
        'status' =>'401',
        'msg' => 'Invalid Request'
        ]); 
      }
    }  // end of GetfilterDietCenterList function   

    public function GetFilterPlanList(Request $request) // start of GetFilterPlanList function 
    { 
      if($request->isMethod('POST'))
      { 
       $type = $request->type; // MONTHLY,PACKAGE,WEEKLY
       $vendor_id = $request->diet_center_id; 
      if($type != "" && $vendor_id != '')
      {
        $ModelCalled = new Websrvc;
        $GetFilterPlanList = $ModelCalled->GetFilterPlanList($type,$vendor_id);
        return response()->json($GetFilterPlanList);
      }
      else
      {
        return response()->json(
          [
          'status' =>'401',
          'msg' => 'All field are required.'
          ]);
      }

      } // check for method post
      else
      {
        return response()->json(
        [
        'status' =>'401',
        'msg' => 'Invalid Request'
        ]); 
      }
    }  // end of GetFilterPlanList function

    public function DeleteAddress(Request $request)
    {
        if($request->isMethod('POST'))
        { 
        $add_id = $request->address_id; // MONTHLY,PACKAGE,WEEKLY
        if($add_id != "")
        {
          $ModelCalled = new Websrvc;
          $DeleteAddress = $ModelCalled->DeleteAddress($add_id);
          return response()->json($DeleteAddress);
        }
        else
        {
          return response()->json(
            [
            'status' =>'401',
            'msg' => 'All field are required.'
            ]);
        }

        } // check for method post
        else
        {
          return response()->json(
          [
          'status' =>'401',
          'msg' => 'Invalid Request'
          ]); 
        }
    }

    public function CurrentOrder(Request $request)  // start of CurrentOrder function 
    {
        if($request->isMethod('POST'))
        { 
        $user_uniqueid = $request->user_uniqueid; 
        if($user_uniqueid != "")
        {
          $ModelCalled = new Websrvc;
          $CurrentOrder = $ModelCalled->CurrentOrder($add_id);
          return response()->json($CurrentOrder);
        }
        else
        {
          return response()->json(
            [
            'status' =>'401',
            'msg' => 'All field are required.'
            ]);
        }

        } // check for method post
        else
        {
          return response()->json(
          [
          'status' =>'401',
          'msg' => 'Invalid Request'
          ]); 
        }
    }          // end of CurrentOrder function

}     // end of class
