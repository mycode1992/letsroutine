<?php

Route::group(['module' => 'Websrvc', 'middleware' => ['api'], 'namespace' => 'App\Modules\Websrvc\Controllers'], function() {

    // Route::resource('websrvc', 'WebsrvcController');
	Route::any('/websrvc/AreaList', 'WebsrvcController@AreaList');
	Route::any('/websrvc/UserLogin', 'WebsrvcController@UserLogin');
	Route::any('/websrvc/RegisterUser', 'WebsrvcController@RegisterUser');  
	Route::any('/websrvc/LoginUser', 'WebsrvcController@LoginUser'); 
	Route::any('/websrvc/ForgotPassword', 'WebsrvcController@ForgotPassword'); 
	Route::any('/websrvc/GetPageLinks', 'WebsrvcController@GetPageLinks'); 
	Route::any('/websrvc/GetSupport', 'WebsrvcController@GetSupport'); 
	Route::any('/websrvc/GetUserInfo', 'WebsrvcController@GetUserInfo'); 
	Route::any('/websrvc/EditUserInfo', 'WebsrvcController@EditUserInfo'); 
	Route::any('/websrvc/UpdatePassword', 'WebsrvcController@UpdatePassword'); 
	Route::any('/websrvc/GetUserWallet', 'WebsrvcController@GetUserWallet'); 
	Route::any('/websrvc/OrderReportProblem', 'WebsrvcController@OrderReportProblem'); 
	Route::any('/websrvc/AddAddress', 'WebsrvcController@AddAddress'); 
	Route::any('/websrvc/GetAddressList', 'WebsrvcController@GetAddressList'); 
	Route::any('/websrvc/MarkAsDefaultAdd', 'WebsrvcController@MarkAsDefaultAdd'); 
	Route::any('/websrvc/GetPlanDietList', 'WebsrvcController@GetPlanDietList');
	Route::any('/websrvc/GetPlanDietDetails', 'WebsrvcController@GetPlanDietDetails');
	Route::any('/websrvc/PlaceYourOrder', 'WebsrvcController@checkout');
	Route::any('/websrvc/GetServiceFee', 'WebsrvcController@GetServiceFee');
	Route::any('/websrvc/GetfilterDietCenterList', 'WebsrvcController@GetfilterDietCenterList');
	Route::any('/websrvc/DeleteAddress', 'WebsrvcController@DeleteAddress');
	Route::any('/websrvc/GetFilterPlanList', 'WebsrvcController@GetFilterPlanList');
	Route::any('/websrvc/CurrentOrder', 'WebsrvcController@CurrentOrder');

	
});
