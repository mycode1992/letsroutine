<?php 

return [
    'welcome' => 'Welcome, this is Admin module.'
];
